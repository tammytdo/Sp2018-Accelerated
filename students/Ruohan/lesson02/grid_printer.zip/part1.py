print('+','-')
print()
print('+',end='')
print('-')
print()
print('this'+'that')
print()

plus = '+'
minus = '-'

print(plus+minus+plus)

print('+'*10)


first_name = 'Ruohan'
last_name = 'Zhang'

print('*'*5+first_name+' '+last_name+'*'*5)
